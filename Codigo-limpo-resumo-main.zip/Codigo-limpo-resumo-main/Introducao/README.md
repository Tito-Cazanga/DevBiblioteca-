# Introdução
Nessa parte será dado uma parte introdutória com uma reflexão.

## Reflexão Inicial

O autor faz uma reflexão sobre como seria seu código se medido por WTF por minuto, isso é, o tanto de esforço mental seria necessário para entendê-lo num code review.

![wtf](../assets/wtf.png "Código limpo e sujo respectivamente em uma revisão")
