# Resumo do Código Limpo
Este repositório tem como o objetivo fixar e servir como consultas futuras as lições apresentadas no livro Código Limpo de Robert Cecil Martin

## Organização
A organização desse repositório será da seguinte maneira:

Cada capítulo será representado por uma pasta, onde irá ter os seus códigos exemplificados no livro (maior parte em Java) e um arquivo Markdown representando as principais lições e uma breve explicação.

**OBS: Nenhum tipo de resumo pode ser tão completo quanto a própria obra, então é recomendado que você leia o Código Limpo para extrair melhor os conceitos**
